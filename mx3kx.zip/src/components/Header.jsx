import React from "react";
import Pozdrav from "../lib/Pozdrav";

function Header() {
  return <header>{Pozdrav()}</header>;
}

export default Header;